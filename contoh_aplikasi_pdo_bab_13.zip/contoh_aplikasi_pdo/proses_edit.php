<?php
include ("hubung_db.php");
include ("header.php");
$xnilai=$_POST["vnilai"];
$xid=$_GET["id"];

$bintang="*"; 
$karakter="";
for ($a=1;$a<=$xnilai;$a++)
   {
	  $karakter=$bintang.$karakter;
   }
   
// Keterangan
if ($xnilai>=100)
  {
	 $keterangan="Besar";
  }
else if ($xnilai>=50 and $xnilai<100)
  {
	 $keterangan="Sedang";
  }
else
  {
	 $keterangan="Kecil";
  }
  
// Update SQL //
$query="update contoh_program set nilai='$xnilai',karakter='$karakter',
        keterangan='$keterangan' where id='$xid'";

if ($dbh->exec($query))
   {
	  echo "Data Berhasil diupdate";
   }
else
   {
	  echo "Error:".$query."<br/>".mysqli_error($conn);
   } 	      	     

echo "<br/><a href='lihat.php'><input type='button' value='Tampil'/></a>";     
echo "</div>";
include ("footer.php");
?>
