<!DOCTYPE html>
<html>
  <head>
     <title>Form</title>
     <link rel="stylesheet" href="style.css" />
  </head>
 <body>
 <div id="kotaknya">
 <nav>
   <ul>
     <li><a href="index.php">Entri</a></li>
     <li><a href="lihat.php">Lihat</a></li>
   </ul>
 </nav>

