<?php
include ("hubung_db.php");
include ("header.php");
$xid=$_GET["id"];

// Update SQL //
$query="delete from contoh_program where id='$xid'";

if ($dbh->query($query))
   {
	  echo "Data Berhasil dihapus";
   }
else
   {
	  echo "Error:".$query."<br/>".mysqli_error($conn);
   } 	      	     

echo "<br/><a href='lihat.php'><input type='button' value='Tampil'/></a>";     
include ("footer.php");
?>
