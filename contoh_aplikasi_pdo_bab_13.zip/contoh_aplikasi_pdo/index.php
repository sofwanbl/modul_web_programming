<?php
  include ("header.php");
?>  
 <table id="tabel_entri">
   <form method="post" action="proses.php">
   <tr>
     <td>Nilai</td><td>:</td><td><input type="text" name="vnilai" size="5" /></td>
   </tr>
   <tr>
     <td><input type="submit" value="Proses" /></td>
   </tr>
    </form> 
 </table> 
 </div>
<?php include("footer.php"); ?>
