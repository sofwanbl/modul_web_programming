<?php 
include ("hubung_db.php"); 
include ("header.php");
?>
 <form method="post" action="<?php $_SERVER['PHP_SELF'];?>" >
 Cari : <input type="text" name="vcari" size="5" /><input type="submit" value="Cari" />
 </form>
 <br/>
 <table border='1' class="tabel_tampil">
   <th>No</th><th>Nilai</th><th>KARAKTER</th><th>KETERANGAN</th><th>Opsi</th> 
   <?php
     if (isset($_POST["vcari"]))
       {
		 $xcari=$_POST["vcari"];   
	   }
	 else
	   {
		 $xcari="";   
	   }	     	   
	 
	 if (strlen($xcari)>0)  
	    {
		  $katawhere=" where nilai='$xcari'";
		}
	 else
	    {
		  $katawhere="";	
		}		  	
	   
	 $query="select * from contoh_program". $katawhere;
	 $result=$dbh->query($query);
	 $no=1;
	 foreach($result as $row)
	  {
	    echo "<tr>";
	    echo "<td>$no</td><td>".$row['nilai']."</td><td>".$row['karakter']."</td>";
	    echo "<td>".$row['keterangan']."</td>";
	    echo "<td><a href='edit.php?id=".$row['id']."'>Edit</a> | <a href='proses_hapus.php?id=".$row['id']."'>Hapus</a></td>";
	    echo "</tr>";
	    $no++;
	  }
	?> 	 
	</table>	 	
  </form>	
</div>	          
<?php include ("footer.php"); ?>  
