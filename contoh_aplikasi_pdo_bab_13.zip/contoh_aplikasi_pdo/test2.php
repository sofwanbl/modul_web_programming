<!DOCTYPE html>
<html>
  <head>
     <title>Form</title>
  </head>
 <body>
 <table>
   <form method="post" action="proses.php">
   <tr>
     <td>Nilai</td><td>:</td><td><input type="text" name="vnilai" size="5" /></td>
   </tr>
   <tr>
     <td><input type="submit" value="Proses" /></td>
   </tr>
    </form> 
 </table> 
 </body>
</html>
