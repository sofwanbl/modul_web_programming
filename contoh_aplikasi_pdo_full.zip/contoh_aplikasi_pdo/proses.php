<?php
include ("hubung_db.php");
include ("header.php");

// Ambil Data Nilai
$xnilai1=$_POST["vnilai"];
echo $xnilai1."<br/>";
$bintang="*"; 
$karakter="";

for ($a=1;$a<=$xnilai1;$a++)
   {
	  $karakter=$bintang.$karakter;
   }

echo $karakter;   

// Keterangan
if ($xnilai1>=100)
  {
	 $keterangan="Besar";
  }
else if ($xnilai1>=50 and $xnilai1<100)
  {
	 $keterangan="Sedang";
  }
else
  {
	 $keterangan="Kecil";
  }

// Insert data ke dalam tabel  // 
$query="insert into contoh_program (nilai,karakter,keterangan)
        values ('$xnilai1','$karakter','$keterangan')";
        

if ($dbh->exec($query))
   {
	  echo "<br/>Data Berhasil disimpan";
   }
else
   {
	  echo "Error:".$sql."<br/>".mysqli_error($conn);
   } 	      	 

echo "<br/><input type='button' value='Back' onClick='history.back()'/>";  
echo "</div>";
include ("footer.php");
?>
