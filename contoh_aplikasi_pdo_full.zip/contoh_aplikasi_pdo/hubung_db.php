<?php
// Koneksi ke database
$dsn='mysql:host=localhost;dbname=test';
$username='root';
$password='opansan';

// server : localhost
// username DB : root
// password DB : opansan245
// namaDB      : test 

try {
	   $dbh=new PDO($dsn,$username,$password);
	}
catch(PDOException $e)
    {
	   echo $e->getMessage();
	}
?>  
