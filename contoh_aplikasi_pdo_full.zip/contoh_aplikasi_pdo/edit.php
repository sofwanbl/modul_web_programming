<?php 
  include ("header.php");
  include ("hubung_db.php");
  $xid=$_GET["id"];
  $query="select * from contoh_program where id='$xid'";
  $result=$dbh->query($query);     
  foreach($result as $row)
    {
       $nilai=$row["nilai"];
    }   
?>
 <table>
   <form method="post" action="proses_edit.php?id=<?php echo $xid;?>">
   <tr>
     <td>Nilai</td><td>:</td><td><input type="text" name="vnilai" value="<?php echo $nilai;?>" size="5" /></td>
   </tr>
   <tr>
     <td><input type="submit" value="Proses" /></td>
   </tr>
    </form> 
 </table> 
<?php 
  include ("footer.php");
?>   
