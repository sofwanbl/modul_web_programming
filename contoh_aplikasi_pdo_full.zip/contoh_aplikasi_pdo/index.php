<!DOCTYPE html>
<html>
 <table id="tabel_entri" align="center">
   <?php     
    if (session_status() ==PHP_SESSION_NONE)
      {
		session_start();
	  }
     session_destroy();     
   ?>  	 
   <form method="post" action="entri.php">
   <caption>Login -- Aplikasi CRUD</caption>	   
   <tr>
     <td>Username</td><td>:</td><td><input type="text" name="vusername" size="10" /></td>
   </tr>
   <tr>
     <td>Password</td><td>:</td><td><input type="password" name="vpassword" size="10" /></td>
   </tr>
   <tr>
     <td colspan="3"><input type="submit" value="Proses" /></td>
   </tr>
    </form> 
 </table> 
 </div>
<?php include("footer.php"); ?>
