<!DOCTYPE html>
<html>
  <head>
     <title>Form</title>
     <link rel="stylesheet" href="style.css" />
  </head>
 <body>
 <div id="kotaknya">
 <nav>
   <ul>
     <li><a href="entri.php">Entri</a></li>
     <li><a href="lihat.php">Lihat</a></li>
     <li><a href="index.php">Logout</a></li>
   </ul>
 </nav>

