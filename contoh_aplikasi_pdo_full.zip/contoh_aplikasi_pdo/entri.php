<?php  
  include ("hubung_db.php");
  $jml=0;    
  if (session_status() ==PHP_SESSION_NONE)
    {
		session_start();
	}
		
  if (isset($_POST["vusername"]))
     {
		$xusername=$_POST["vusername"];
	 }
  
  if (isset($_POST["vpassword"]))
     { 	 	 
	   $xpassword=$_POST["vpassword"];
	   $zpassword=md5($xpassword);
	 }
  else
     {
	   $zpassword="";
	 }  	 	 

  if (isset($_POST["vusername"]) && isset($_POST["vpassword"]))
    {
      $query="select count(*) from user where username='$xusername' and password='$zpassword'"; 		 
      $hasil=$dbh->query($query);
  
      $jml=$hasil->fetchColumn();
    } 
     
  if ($jml>0 || isset($_SESSION["logged_in"]))
    {
	 include ("header.php");	 
	 $_SESSION["logged_in"]=true;	
	 
   ?>  
 <table id="tabel_entri">
   <form method="post" action="proses.php">
   <tr>
     <td>Nilai</td><td>:</td><td><input type="text" name="vnilai" size="5" /></td>
   </tr>
   <tr>
     <td><input type="submit" value="Proses" /></td>
   </tr>
    </form> 
 </table> 
 </div> 
 <?php
   }
 else
   {
	  $_SESSION["logged_in"]=0;
	  echo "<center>User tidak ada</center>";
	  echo "<br/>";
	  include("index.php");
   }	   	   
include("footer.php"); 
?>
