<?php 
if (session_status()==PHP_SESSION_NONE)
   {
	 session_start();
   }
	
if (isset($_SESSION["logged_in"]))
  {
	include ("hubung_db.php"); 
    include ("header.php");
?>
 <form method="post" action="<?php $_SERVER['PHP_SELF'];?>" >
 Cari : <input type="text" name="vcari" size="5" /><input type="submit" value="Cari" />
 </form>
 <br/>
 <table border='1' class="tabel_tampil">
   <th>No</th><th>Nilai</th><th>KARAKTER</th><th>KETERANGAN</th><th>Opsi</th> 
   <?php
     
     if (isset($_POST["vcari"]))
       {
		 $xcari=$_POST["vcari"];   
	   }
	 else
	   {
		 $xcari="";   
	   }	     	   
	 
	 if (strlen($xcari)>0)  
	    {
		  $katawhere=" where nilai='$xcari'";
		}
	 else
	    {
		  $katawhere="";	
		}		  	
	   
	 // Cari Total //
	 $halaman=3;  
	 if (isset($_GET['halaman']))
	    {
		  $hal=(int)$_GET['halaman'];
		} 	
	 else
	    {
		  $hal=1;
		}
		 	  	 	
	 if ($hal>1)
	   {
		  $mulai=($hal-1)*$halaman;
	   }	   
	 else
	   {
		  $mulai=0;
	   }	     
	 
	 $query_total="Select count(*) from contoh_program". $katawhere;    
	 $query_totalnya=$dbh->query($query_total);
	 $total=$query_totalnya->fetchColumn();
	 $halamannya=ceil($total/$halaman);	
	 	  
	 $query="select * from contoh_program". $katawhere ." limit $mulai, $halaman";
	 $result=$dbh->query($query);
	 
	 $no=$mulai+1;
	 foreach($result as $row)
	  {
	    echo "<tr>";
	    echo "<td>$no</td><td>".$row['nilai']."</td><td>".$row['karakter']."</td>";
	    echo "<td>".$row['keterangan']."</td>";
	    echo "<td><a href='edit.php?id=".$row['id']."'>Edit</a> | <a href='proses_hapus.php?id=".$row['id']."'>Hapus</a></td>";
	    echo "</tr>";
	    $no++;
	  }
	?> 	 
	</table>	 	
  </form>	
  <br/>
  <center>
  <?php
  for ($i=1;$i<=$halamannya;$i++)
     { ?>
		 <a href="?halaman=<?php echo $i;?>"><?php echo $i;?></a>
 <?php
  	 }	   	 
  ?>   
  </center>
  <br/>
</div>	          
<?php 
   }
else
   {
	  include("index.php");
   }
include ("footer.php"); 
?>  
